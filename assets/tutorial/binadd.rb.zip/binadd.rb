#!/usr/bin/env ruby
def bin_xor(ai,bi)
	ai != bi ? 1 : 0
end

def bin_and(ai,bi)
	(ai == bi and bi == 1 )? 1 : 0
end

def bin_or(ai,bi)
	ai == 1 || bi == 1 ? 1 : 0
end

def bin_add(a,b)                 # a b 是兩個被加法的二進制字符串(String)
	a = a.split('').map(&:to_i)   # 將兩個串轉成數組,eg "110011" -> [1,1,0,0,1,1]
	b = b.split('').map(&:to_i)
	len = [a.length,b.length].max # a b 長度的最大值
	shift = 0                     # 進位值
	result = []                   # 保存結果
	for i in 0..len 
		ai = a[-1 - i] || 0
		bi = b[-1 - i] || 0
		simpleAdd = bin_xor(ai,bi)
		ri = bin_xor( simpleAdd, shift)
		newShift = bin_or( bin_and(ai,bi) , bin_and(simpleAdd,shift))
		puts "pos(#{i}) - a:[#{ai}], b:[#{bi}], r:[#{ri}], old shift:[#{shift}], new shift:[#{newShift}]"
		result.unshift ri
		shift = newShift
	end
	puts "final result:"
	result = result.join
	puts result," <=> ",result.to_i(2) 
end

if __FILE__ == $0 
	begin
	   raise ArgumentError if ARGV.length < 2
		Integer(ARGV[0],2)
		Integer(ARGV[1],2)
		bin_add ARGV[0],ARGV[1]
	rescue ArgumentError
		puts "Usage: #$0 (binary number) (binary number)"
	end
end
